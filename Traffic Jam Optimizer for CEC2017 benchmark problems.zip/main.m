
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%  Traffic Jam Optimizer (TJO) source codes version 1.0
%  
%  Developed in:	MATLAB 23.2.0.2365128 (R2023b)
%  
%  Programmer:		Jinpeng Wang
%                   e-mail: wangjinpengchunuo@163.com &
%                   2211060117@std.lntu.edu.cn
%  
%  Original paper:	Jinpeng Wang, Ziyang Shang, 
%                   Traffic jam optimizer: A novel swarm-inspired
%                   metaheuristic algorithm for solving global
%                   optimization problems 
%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% To use this code in your own project 
% remove the line for 'CEC2017' function 
% and define the following parameters: 
% fun   : function handle to the .m file containing the objective function
%		  the .m file you define should accept the whole population 'x' 
%		  as input and return a column vector containing objective function 
%		  values of all of the population members
% nvars : number of decision/design variables 
% lb    : lower bound of decision variables (must be of size 1 x nvars)
% ub    : upper bound of decision variables (must be of size 1 x nvars)
%
% TJO will return the following: 
% x     : best solution found 
% fval  : objective function value of the found solution 

clc
clear
close all
%% Inputs 

FunctionNumber = 'F1'; % F1~F30 except F2
D=50;
options.CarNum = 50;
options.MaxIterations  = 500;
options.a = [0.5, 1.5];
options.c = [1.5, 0.5];

[lb,ub,nvars,fun] = GetFunctionsDetails(FunctionNumber,D);
%% Traffic Jam Optimizer
[x,fval,ConvergenceCurve] = TJO (fun,nvars,lb,ub, options);
%% Plot results 
figure
plot(log(ConvergenceCurve));
xlabel('Iterations');
ylabel('Ln Objective function');
title('Convergence curve');