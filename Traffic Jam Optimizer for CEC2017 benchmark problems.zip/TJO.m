
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%  Traffic Jam Optimizer (TJO) source codes version 1.0
%  
%  Developed in:	MATLAB 23.2.0.2365128 (R2023b)
%  
%  Programmer:		Jinpeng Wang
%                   e-mail: wangjinpengchunuo@163.com &
%                   2211060117@std.lntu.edu.cn
%  
%  Original paper:	Jinpeng Wang, Ziyang Shang, 
%                   Traffic jam optimizer: A novel swarm-inspired
%                   metaheuristic algorithm for solving global
%                   optimization problems 
%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [bestx,bestf,ConvergenceCurve] = TJO (fun,nvars,lb,ub,options)

%% initialization

N = options.CarNum;
T = options.MaxIterations;

ConvergenceCurve  = zeros (1, T);
[x, lb, ub]=Initialization(N,nvars,ub,lb);
for i = 1:N
    f(i,:) = fun (x(i,:));
end
[bestf,index] = min(f);
bestx = x(index,:);
FlockMemoryF = f;
FlockMemoryX = x;
a = linspace (options.a(1), options.a(2), T);
c = linspace (options.c(1), options.c(2), T);
%% main loop

for t = 1 : T

    r = t/T;
    % Calculate the best position for each driver
    BestX = (1-r).*FlockMemoryX + r.*bestx;
    % Drivers driving randomly causing traffic jam
    y = (1-r)*exp(-r)*sin(2*pi*rand(N,1)).*cos(2*pi*rand(N,1)).*c(t);
    x = BestX + y.*((ub-lb).*rand(N,nvars)+lb);
    % Drivers self-adjustment
    for i = 1:N
        if rand>0.5
            x(i,:) = x(i,:) + c(t)*sin(pi*rand).*(x(randi(N),:) - x(i,:));
        else
            x(i,:) = x(i,:) + c(t)*sin(pi*rand).*(BestX(randi(N),:) - x(i,:));
        end
    end
    % Traffic police directing drivers to drive
    x = BestX + a(t)*sin(2*pi*rand(N,1)).*(BestX - x);
    
    % Cross-border processing
    lbExtended = repmat (lb,[N,1]);
    ubExtended = repmat (ub,[N,1]);
    
    lbViolated = x < lbExtended;
	ubViolated = x > ubExtended;
	
	x (lbViolated) = lbExtended (lbViolated);
	x (ubViolated) = ubExtended (ubViolated);
	
	% Calculate fitness
    for i = 1:N
        f(i,:) = fun (x(i,:));
    end

    % Update memory
	UpdateMask = f < FlockMemoryF;
	FlockMemoryF (UpdateMask) = f (UpdateMask);
	FlockMemoryX (UpdateMask,:) = x (UpdateMask,:);

    % Update best individual
    if min(f)<bestf
        [bestf,index] = min(f);
        bestx = x(index,:);
    end

    % Record convergence curve
    ConvergenceCurve (t) = bestf;

end