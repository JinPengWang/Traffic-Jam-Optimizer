
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%  Traffic Jam Optimizer (TJO) source codes version 1.0
%  
%  Developed in:	MATLAB 23.2.0.2365128 (R2023b)
%  
%  Programmer:		Jinpeng Wang
%                   e-mail: wangjinpengchunuo@163.com &
%                   2211060117@std.lntu.edu.cn
%  
%  Original paper:	Jinpeng Wang, Ziyang Shang, 
%                   Traffic jam optimizer: A novel swarm-inspired
%                   metaheuristic algorithm for solving global
%                   optimization problems 
%   
% This function contains the complete information and implementation of the benchmark function CEC2017

% This function is used to initialize the population
function [x, new_lb, new_ub]=Initialization(PopSize,nvars,ub,lb)

num= size(ub,2); % Number of boundaries
new_lb = lb;
new_ub = ub;

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if num==1
    x=rand(PopSize,nvars).*(ub-lb)+lb;
    new_lb = lb*ones(1,nvars);
    new_ub = ub*ones(1,nvars);
end

% If each variable has a different lb and ub
if num>1
    for i=1:nvars
        ubi=ub(i);
        lbi=lb(i);
        x(:,i)=rand(PopSize,1).*(ubi-lbi)+lbi;
    end
end